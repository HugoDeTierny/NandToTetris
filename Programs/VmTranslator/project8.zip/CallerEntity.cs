﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VmTranslator
{
    internal class CallerEntity
    {
        public string Caller {  get; set; }
        public int index { get; set; }
    }
}
