# Module 5 - Project 9 - Homework

## The project implement the clasical Snake game
    * User can use the arrow keys in order to guide the snake towards the food / prey and collect as many points as possible
    * The game finishes as soon there is a collision with the exterior walls or with any blocks of the snake  

## Zip archive is split in two folders
    * bin/ - contains the compiled *.vm files that can be loaded in VMEmulator and the project verified
    * source/ - contains all the source file for the project